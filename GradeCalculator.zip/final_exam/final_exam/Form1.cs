﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

/*
Daniel Venturole
Final Exam
Version 1.0
27/04/2023
*/

namespace final_exam
{

    public partial class Form1 : Form
    {
        //criar um arquivo novo pra fazer a classe de validação e declarar aqui
        //Nome_classe nome_objeto que vou usar
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtInput.Text = "Daniel Venturole 2234583";
        }

        private void btnImage_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
            obj.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e) //section 3.1
        {
            if ((MessageBox.Show("Do you want to quit this Application",
             "Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)).ToString() == "OK")
            {
                this.Close();
            }
            else
            {
                txtInput.Text = "";

            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtInput.Clear();
            cbYear.ResetText();
            cbSession.ResetText();
        }
    }
}
