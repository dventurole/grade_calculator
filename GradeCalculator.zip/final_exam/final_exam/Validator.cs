﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

namespace final_exam
{
    class Validator //section 2.2
    {
        private int year, session;

        public int Year
        {
            get { return year; }
            set { year = value; }
        }
        public int Session
        {
            get { return session; }
            set { session = value; }
        }

        //methods
        public bool valYear(string year)
        {
            Regex rgxYear = new Regex(@"^[202](\d)$");

            if (rgxYear.IsMatch(year) == true)
                return true;
            else
            {
                return false;
            }
        }

        public bool valSession(string session)
        {
            Regex rgxSession = new Regex(@"^((Fall)|(Winter)|(Summer))$");

            if (rgxSession.IsMatch(session) == true)
                return true;
            else
            {
                return false;
            }
        }

        public bool valGrade(string grade)
        {
            Regex rgxGrade = new Regex(@"^(100|\d{1,2})$");

            if (rgxGrade.IsMatch(grade) == true)
                return true;
            else
            {
                return false;
            }

        }

    }
}
