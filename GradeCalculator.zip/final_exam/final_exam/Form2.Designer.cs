﻿namespace final_exam
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMidterm = new System.Windows.Forms.TextBox();
            this.txtMidtermGrade = new System.Windows.Forms.TextBox();
            this.txtProjectGrade = new System.Windows.Forms.TextBox();
            this.txtProject = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtFinalGrade = new System.Windows.Forms.TextBox();
            this.txtFinal = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTotalGrade = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnValDate = new System.Windows.Forms.Button();
            this.btnWriteStud = new System.Windows.Forms.Button();
            this.btnCreateXml = new System.Windows.Forms.Button();
            this.btnReadXml = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Midterm Exam:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(265, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "grade (0 to 100)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(550, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "(0 to 30%)";
            // 
            // txtMidterm
            // 
            this.txtMidterm.Location = new System.Drawing.Point(139, 40);
            this.txtMidterm.Name = "txtMidterm";
            this.txtMidterm.Size = new System.Drawing.Size(120, 26);
            this.txtMidterm.TabIndex = 3;
            this.txtMidterm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMidtermGrade
            // 
            this.txtMidtermGrade.Location = new System.Drawing.Point(424, 40);
            this.txtMidtermGrade.Name = "txtMidtermGrade";
            this.txtMidtermGrade.ReadOnly = true;
            this.txtMidtermGrade.Size = new System.Drawing.Size(120, 26);
            this.txtMidtermGrade.TabIndex = 4;
            this.txtMidtermGrade.Text = "0";
            this.txtMidtermGrade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtProjectGrade
            // 
            this.txtProjectGrade.Location = new System.Drawing.Point(424, 101);
            this.txtProjectGrade.Name = "txtProjectGrade";
            this.txtProjectGrade.ReadOnly = true;
            this.txtProjectGrade.Size = new System.Drawing.Size(120, 26);
            this.txtProjectGrade.TabIndex = 9;
            this.txtProjectGrade.Text = "0";
            this.txtProjectGrade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtProject
            // 
            this.txtProject.Location = new System.Drawing.Point(139, 101);
            this.txtProject.Name = "txtProject";
            this.txtProject.Size = new System.Drawing.Size(120, 26);
            this.txtProject.TabIndex = 8;
            this.txtProject.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(550, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "(0 to 30%)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(265, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "grade (0 to 100)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Project:";
            // 
            // txtFinalGrade
            // 
            this.txtFinalGrade.Location = new System.Drawing.Point(424, 163);
            this.txtFinalGrade.Name = "txtFinalGrade";
            this.txtFinalGrade.ReadOnly = true;
            this.txtFinalGrade.Size = new System.Drawing.Size(120, 26);
            this.txtFinalGrade.TabIndex = 14;
            this.txtFinalGrade.Text = "0";
            this.txtFinalGrade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFinal
            // 
            this.txtFinal.Location = new System.Drawing.Point(139, 163);
            this.txtFinal.Name = "txtFinal";
            this.txtFinal.Size = new System.Drawing.Size(120, 26);
            this.txtFinal.TabIndex = 13;
            this.txtFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(550, 166);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "(0 to 40%)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(265, 169);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 20);
            this.label8.TabIndex = 11;
            this.label8.Text = "grade (0 to 100)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 169);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 20);
            this.label9.TabIndex = 10;
            this.label9.Text = "Final:";
            // 
            // txtTotalGrade
            // 
            this.txtTotalGrade.Location = new System.Drawing.Point(424, 223);
            this.txtTotalGrade.Name = "txtTotalGrade";
            this.txtTotalGrade.ReadOnly = true;
            this.txtTotalGrade.Size = new System.Drawing.Size(120, 26);
            this.txtTotalGrade.TabIndex = 19;
            this.txtTotalGrade.Text = "F";
            this.txtTotalGrade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(139, 223);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(120, 26);
            this.txtTotal.TabIndex = 18;
            this.txtTotal.Text = "0";
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(550, 226);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(124, 40);
            this.label10.TabIndex = 17;
            this.label10.Text = "A, B, C, D or F\r\n(60 to 100 pass)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(265, 229);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 20);
            this.label11.TabIndex = 16;
            this.label11.Text = "grade (0 to 100)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 229);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 20);
            this.label12.TabIndex = 15;
            this.label12.Text = "Total:";
            // 
            // btnValDate
            // 
            this.btnValDate.Location = new System.Drawing.Point(40, 295);
            this.btnValDate.Name = "btnValDate";
            this.btnValDate.Size = new System.Drawing.Size(158, 79);
            this.btnValDate.TabIndex = 20;
            this.btnValDate.Text = "&Validate-Calculate\r\nDate";
            this.btnValDate.UseVisualStyleBackColor = true;
            this.btnValDate.Click += new System.EventHandler(this.btnValDate_Click);
            // 
            // btnWriteStud
            // 
            this.btnWriteStud.Location = new System.Drawing.Point(228, 295);
            this.btnWriteStud.Name = "btnWriteStud";
            this.btnWriteStud.Size = new System.Drawing.Size(158, 79);
            this.btnWriteStud.TabIndex = 21;
            this.btnWriteStud.Text = "&Write/Add student data into final.txt";
            this.btnWriteStud.UseVisualStyleBackColor = true;
            this.btnWriteStud.Click += new System.EventHandler(this.btnWriteStud_Click);
            // 
            // btnCreateXml
            // 
            this.btnCreateXml.Location = new System.Drawing.Point(416, 295);
            this.btnCreateXml.Name = "btnCreateXml";
            this.btnCreateXml.Size = new System.Drawing.Size(158, 79);
            this.btnCreateXml.TabIndex = 22;
            this.btnCreateXml.Text = "&Create/Write xml final.xml file from txt file";
            this.btnCreateXml.UseVisualStyleBackColor = true;
            this.btnCreateXml.Click += new System.EventHandler(this.btnCreateXml_Click);
            // 
            // btnReadXml
            // 
            this.btnReadXml.Location = new System.Drawing.Point(604, 295);
            this.btnReadXml.Name = "btnReadXml";
            this.btnReadXml.Size = new System.Drawing.Size(158, 79);
            this.btnReadXml.TabIndex = 23;
            this.btnReadXml.Text = "&Read xml final.xml file and display";
            this.btnReadXml.UseVisualStyleBackColor = true;
            this.btnReadXml.Click += new System.EventHandler(this.btnReadXml_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(162, 380);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(106, 58);
            this.btnReset.TabIndex = 24;
            this.btnReset.Text = "R&eset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(526, 380);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(106, 58);
            this.btnExit.TabIndex = 25;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnReadXml);
            this.Controls.Add(this.btnCreateXml);
            this.Controls.Add(this.btnWriteStud);
            this.Controls.Add(this.btnValDate);
            this.Controls.Add(this.txtTotalGrade);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtFinalGrade);
            this.Controls.Add(this.txtFinal);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtProjectGrade);
            this.Controls.Add(this.txtProject);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtMidtermGrade);
            this.Controls.Add(this.txtMidterm);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Daniel, Venturole - 2234583 27/04/2023";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMidterm;
        private System.Windows.Forms.TextBox txtMidtermGrade;
        private System.Windows.Forms.TextBox txtProjectGrade;
        private System.Windows.Forms.TextBox txtProject;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtFinalGrade;
        private System.Windows.Forms.TextBox txtFinal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTotalGrade;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnValDate;
        private System.Windows.Forms.Button btnWriteStud;
        private System.Windows.Forms.Button btnCreateXml;
        private System.Windows.Forms.Button btnReadXml;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
    }
}