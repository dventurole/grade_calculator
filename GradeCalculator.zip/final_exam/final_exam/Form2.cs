﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Text.RegularExpressions;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace final_exam
{
    public partial class Form2 : Form
  
    {
        string path = @"CSExam.txt";
        private const string pathxml = @"Results.xml";
        FileStream fs = null;
        Validator data;
        FGgrades calc;
        public Form2()
        {
            InitializeComponent();
        }
        double midterm, project, final; // global variables

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show("Do you want to quit this Application",
             "Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)).ToString() == "OK")
            {
                this.Close();
            }
            else
            {
                txtMidterm.Text = "";
                txtProject.Text = "";
                txtFinal.Text = "";
                txtTotal.Text = "";
                txtMidtermGrade.Text = "";
                txtProjectGrade.Text = "";
                txtFinalGrade.Text = "";
                txtTotalGrade.Text = "";


            }
        }

        private void btnWriteStud_Click(object sender, EventArgs e)
        {
            fs = new FileStream(path, FileMode.Append, FileAccess.Write);
            StreamWriter textOut = new StreamWriter(fs);

            midterm = Convert.ToDouble(txtMidterm.Text);
            project = Convert.ToDouble(txtProject.Text);
            final = Convert.ToDouble(txtFinal.Text);

            textOut.WriteLine("Midterm: " + midterm + ",\t Project: " + project + ",\t Final: " + final);

            textOut.Close();
            MessageBox.Show("The grade was appended to the Text File", "Grade Registered");
        }

        private void btnCreateXml_Click(object sender, EventArgs e)
        {
            if (txtMidterm.Text != "" && txtProject.Text != "" && txtFinal.Text != "")
            {
                calc.WriteXml();
            }
            else
            {
                MessageBox.Show("Please insert all the grades first");
            }

        }

        private void btnReadXml_Click(object sender, EventArgs e)
        {
            if (txtMidterm.Text != "" && txtProject.Text != "" && txtFinal.Text != "")
            {
                calc.ReadXml();
            }
            else
            {
                MessageBox.Show("Please insert all the grades first");
            }

            

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtMidterm.Clear();
            txtProject.Clear();
            txtFinal.Clear();
            txtTotal.Clear();
            txtMidtermGrade.Clear();
            txtProjectGrade.Clear();
            txtFinalGrade.Clear();
            txtTotalGrade.Clear();
        }

        private void btnValDate_Click(object sender, EventArgs e)
        {
            data = new Validator(); //create object data to validate grades 
            calc = new FGgrades(midterm, project, final); // create object to validate course information

            try
            {
                
                if (data.valGrade(txtMidterm.Text) == true)
                {
                    txtProject.Focus();
                    txtMidtermGrade.Text = Convert.ToString(calc.letterGrade(Convert.ToDouble(txtMidterm.Text)));

                    if (data.valGrade(txtProject.Text) == true)
                    {
                        txtFinal.Focus();
                        txtProjectGrade.Text = Convert.ToString(calc.letterGrade(Convert.ToDouble(txtProject.Text)));

                        if (data.valGrade(txtFinal.Text) == true)
                        {
                            txtFinalGrade.Text = Convert.ToString(calc.letterGrade(Convert.ToDouble(txtFinal.Text)));
                            txtTotal.Text = Convert.ToString(calc.pctCalc(Convert.ToDouble(txtProject.Text)) +
                                calc.pctCalc(Convert.ToDouble(txtMidterm.Text)) +
                                calc.pctFinalCalc(Convert.ToDouble(txtFinal.Text)));
                            txtTotalGrade.Text = Convert.ToString(calc.letterGrade(Convert.ToDouble(txtTotal.Text)));
                        }
                        else
                        {
                            txtFinal.Focus();
                            MessageBox.Show("Invalid grade", "Error");
                        }
                    }
                    else
                    {
                        txtProject.Focus();
                        MessageBox.Show("Invalid grade", "Error");
                    }
                }
                else
                {
                    txtMidterm.Focus();
                    MessageBox.Show("Invalid grade", "Error");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                txtMidterm.Focus();
                txtMidterm.Text = "";
            }

        }
    }
}
