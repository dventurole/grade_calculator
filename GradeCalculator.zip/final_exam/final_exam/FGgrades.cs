﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace final_exam
{
    class FGgrades //section 2.1
    {
        string path = @"CSExam.txt";
        private const string pathxml = @"Results.xml";
        FileStream fs = null;

        private double midterm, project, final;

        public double Midterm
        {
            get { return midterm; }
            set { midterm = value; }
        }
        public double Project
        {
            get { return project; }
            set { project = value; }
        } 
        public double Final
        {
            get { return final; }
            set { final = value; }
        }

        //constructors

        //default constructor
        public FGgrades() { } //for compatibility with older Visual Studio versions

        //constructor with 1 parameter
        public FGgrades(double midterm) //input data for the object created with the class FGgrades
        {
            this.Midterm = midterm;
            this.Project = project;
            this.Final = final;
        }

        //constructor with 2 parameters
        public FGgrades(double midterm, double project) //input data for the object created with the class FGgrades
        {
            this.Midterm = midterm;
            this.Project = project;
            this.Final = final;
        }

        //constructor with 3 parameters
        public FGgrades(double midterm, double project, double final) //input data for the object created with the class FGgrades
        {
            this.Midterm = midterm;
            this.Project = project;
            this.Final = final;
        }

        //methods

        double pct;
        string result;

        public double pctCalc(double grade)
        {
            pct = grade * 0.3;
            return pct;
        }

        public double pctFinalCalc(double grade)
        {
            pct = grade * 0.4;
            return pct;
        }

        public string letterGrade(double input)
        {
            if (input >= 90 && input <= 100)
            {
                result = "A";
                return result;
            }
            else if (input >= 80 && input < 90)
            {
                result = "B";
                return result;
            }
            else if (input >= 70 && input < 80)
            {
                result = "C";
                return result;
            }
            else if (input >= 60 && input < 70)
            {
                result = "D";
                return result;
            }
            else if (input >= 0 && input < 60)
            {
                result = "F";
                return result;
            }
            else
            {
                result = "Not a grade";
                return result;
            }

        }

        public void WriteXml()
        {
            try
            {
                fs = new FileStream(path, FileMode.Open, FileAccess.Read);
                StreamReader textIn = new StreamReader(fs);
                string textToPrint = "";

                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true; settings.IndentChars = (" ");
                // create the XmlWriter object
                XmlWriter xmlOut = XmlWriter.Create(pathxml, settings);
                // write the start of the document
                xmlOut.WriteStartDocument();
                xmlOut.WriteStartElement("Students");//open root element
                {
                    string row = "";
                    while (textIn.Peek() != -1)
                    {
                        row = textIn.ReadLine();
                        string[] columns = row.Split(',');
                        textToPrint += row + "\n";

                        xmlOut.WriteStartElement("Grades");//open child element
                        xmlOut.WriteElementString("Midterm", columns[0]);//child of child element
                        xmlOut.WriteElementString("Project", columns[1]);//child of child element
                        xmlOut.WriteElementString("Final", columns[2]);//child of child element
                        xmlOut.WriteEndElement();//close child element

                    }
                    xmlOut.WriteEndElement();//closing root element
                    MessageBox.Show(textToPrint);
                    // close the input stream for the text file
                    textIn.Close();
                }
                xmlOut.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "IOException");
            }
            finally { if (fs != null) fs.Close(); }
        }

        public void ReadXml()
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;
            // create the XmlReader object
            XmlReader xmlIn = XmlReader.Create(pathxml, settings);
            string tempStr = "", midterm = "", project = "", final = "";
            // read past all nodes to the first User node
            if (xmlIn.ReadToDescendant("Grades"))
            {
                // create (concatenate) into a string for each User node child data
                do
                {
                    xmlIn.ReadStartElement("Grades");
                    midterm = xmlIn.ReadElementContentAsString(); //read each element
                    project = xmlIn.ReadElementContentAsString();
                    final = xmlIn.ReadElementContentAsString();
                    tempStr += midterm + ", " + project + ", " + final + "\n"; // full line

                }
                while (xmlIn.ReadToNextSibling("Grades"));
            }
            // close the XmlReader object
            MessageBox.Show(tempStr, "Reading");
            xmlIn.Close();
        
    }
    }
}
